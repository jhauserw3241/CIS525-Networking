1.) gcc -o dir dir.c
2.) gcc -o server server.c
3.) gcc -o client client.c
4.) ./dir
5.) ./server test 1234
6.) ./server football 9191
7.) ./client