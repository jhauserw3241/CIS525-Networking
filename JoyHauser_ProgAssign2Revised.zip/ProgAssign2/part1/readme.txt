1.) gcc -o server server.c
2.) gcc -o client client.c
5.) ./server
6.) ./client